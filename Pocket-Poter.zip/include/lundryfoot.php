<?php 
require 'include/lanconfig.php';
$afile = $main['data'];
echo $afile;
?>
