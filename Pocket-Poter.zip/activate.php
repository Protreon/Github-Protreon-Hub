<!doctype html>
<html lang="en">

    

<?php include 'include/head.php';?>
    <body>
        <div class="account-pages my-5 pt-sm-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8 col-lg-6 col-xl-5">
					<div id="getmsg"></div>
                        <div class="card overflow-hidden">
                            <div class="bg-primary bg-soft">
                                <div class="row">
                                    <div class="col-7">
                                        <div class="p-4" style="color:white;">
                                            <h5 class="" style="color:white;">Welcome Back !</h5>
                                            <p>Activate to continue to Access Data.</p>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="card-body pt-0"> 
                                
                                <div class="p-2">
                                    <form class="form-horizontal" method="post">
        
                                        <div class="mb-3">
                                            <label for="username" class="form-label">Enter User App Enavato Code</label>
                                            <input type="text" class="form-control" id="inputCode" name="username" placeholder="Enter Enavato Purchase Code" required>
                                        </div>
                
                                       <div class="mb-3">
                                                                                        <label for="username" class="form-label">Enter Delivery Boy App Enavato Code (Purchase From <a href="https://1.envato.market/jW4QM0" target="_blank">click here</a>)</label>
                                            <input type="text" class="form-control" id="inputCode1" name="username" placeholder="Enter Enavato Purchase Code" required>
                                        </div>
										
										

                                       
                                        
                                        <div class="mt-3 d-grid">
                                            <button class="btn btn-primary waves-effect waves-light" id="sub_activate" type="submit">Activate</button>
                                        </div>
            
                                        
                                    </form>
                                </div>
            
                            </div>
                        </div>
                        <div class="mt-5 text-center">
                            
                           
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- end account-pages -->

      <?php include 'include/lundryfoot.php';?>
	
    </body>


</html>
