<!doctype html>
<html lang="en">

    

<?php include 'include/head.php';?>

    <body>

    <!-- <body data-layout="horizontal" data-topbar="dark"> -->

        <!-- Begin page -->
        <div id="layout-wrapper">

            
            <?php include 'include/inside.php';?>

            <!-- ========== Left Sidebar Start ========== -->
           <?php include 'include/sidebar.php';?>
            <!-- Left Sidebar End -->

            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">
<div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
									<?php 
					$data = $lundry->query("select * from tbl_setting")->fetch_assoc();
					?>
					<h4 class="card-title mb-4">Edit Setting </h4>
					<h5 class="h5_set"><i class="fa fa-gear fa-spin"></i>  General  Information</h5>
					
					<form method="post" enctype="multipart/form-data">
                                       <div class="row">
									    <div class="form-group col-3">
                                            <label><span class="text-danger">*</span> Website Name</label>
                                            <input type="text" class="form-control " placeholder="Enter Store Name" value="<?php echo $data['webname'];?>" name="webname" required="">
                                        </div>
										
                                      <div class="form-group col-3" style="margin-bottom: 48px;">
                                            <label><span class="text-danger">*</span> Website Image</label>
                                            <div class="custom-file">
                                                <input type="file" name="weblogo" class="custom-file-input form-control">
                                                <label class="custom-file-label">Choose Website Image</label>
												<br>
												<img src="<?php echo $data['weblogo'];?>" width="60" height="60"/>
                                            </div>
                                        </div>
										
										<div class="form-group col-3">
									<label for="cname">Select Timezone</label>
									<select name="timezone" class="form-control" required>
									<option value="">Select Timezone</option>
									<?php 
								$tzlist = DateTimeZone::listIdentifiers(DateTimeZone::ALL);
								$limit =  count($tzlist);
								?>
									<?php 
									for($k=0;$k<$limit;$k++)
									{
									?>
									<option <?php echo $tzlist[$k];?> <?php if($tzlist[$k] == $data['timezone']) {echo 'selected';}?>><?php echo $tzlist[$k];?></option>
									<?php } ?>
									</select>
								</div>
										
										<div class="form-group col-3">
                                            <label><span class="text-danger">*</span> Currency</label>
                                            <input type="text" class="form-control" placeholder="Enter Currency"  value="<?php echo $data['currency'];?>" name="currency" required="">
                                        </div>
										
										
										
										
										
										
										
									<div class="form-group col-3">
                                            <label><span class="text-danger">*</span> Minimum Payout for Delivery Boy</label>
                                            <input type="text" class="form-control numberonly" placeholder="Enter Payout for Delivery Boy"  value="<?php echo $data['pdboy'];?>" name="pdboy" required="">
                                        </div>
										
										<div class="form-group col-3">
                                            <label><span class="text-danger">*</span>Google Map Key</label>
                                            <input type="text" class="form-control" placeholder="Enter Google Map Key"  value="<?php echo $data['gkey'];?>" name="gkey" required="">
                                        </div>
										
										<div class="form-group col-3">
                                            <label id="no2" style=""><span class="text-danger">*</span> Select Movers Use Vehicle Type</label>
                                            <select name="vehiid" class="form-control" required>
											<option value="">Select Vehicle Type</option>
											<?php 
											$zone = $lundry->query("select * from tbl_vehicle where status=1");
											while($row = $zone->fetch_assoc())
											{
											?>
											<option value="<?php echo $row['id'];?>" <?php if($data['vehiid'] == $row['id']){echo 'selected';}?>><?php echo $row['title'];?></option>
											<?php } ?>
											</select>
                                        </div>
										
										<div class="form-group col-3">
                                            <label id="no2" style=""><span class="text-danger">*</span> Select Courier Use Vehicle Type</label>
                                            <select name="couvid" class="form-control" required>
											<option value="">Select Vehicle Type</option>
											<?php 
											$zone = $lundry->query("select * from tbl_vehicle where status=1");
											while($row = $zone->fetch_assoc())
											{
											?>
											<option value="<?php echo $row['id'];?>" <?php if($data['couvid'] == $row['id']){echo 'selected';}?>><?php echo $row['title'];?></option>
											<?php } ?>
											</select>
                                        </div>
										<div class="form-group col-12">
										<h5 class="h5_set"><i class="fa fa-truck"></i> Parcel Order Data Information</h5>
										</div>
										
										<div class="form-group col-6">
                                            <label><span class="text-danger">*</span> Parcel Kg Limit</label>
                                            <input type="text" class="form-control " placeholder="Enter Parcel Kg Limit"  value="<?php echo $data['kglimit'];?>" name="kglimit" required="">
                                        </div>
										
										
										
										<div class="form-group col-6">
                                            <label><span class="text-danger">*</span> Per Kg Price</label>
                                            <input type="text" class="form-control " placeholder="Enter Per Kg Price"  value="<?php echo $data['kgprice'];?>" name="kgprice" required="">
                                        </div>
										
										
										<div class="form-group col-12">
										<h5 class="h5_set"><i class="fa fa-truck"></i> Support Data Information</h5>
										</div>
										
										<div class="form-group col-6">
                                            <label><span class="text-danger">*</span> Support Email</label>
                                            <input type="email" class="form-control " placeholder="Enter Support Email"  value="<?php echo $data['semail'];?>" name="semail" required="">
                                        </div>
										
										
										
										<div class="form-group col-6">
                                            <label><span class="text-danger">*</span> Support Mobile</label>
                                            <input type="text" class="form-control " placeholder="Enter Support Mobile"  value="<?php echo $data['smobile'];?>" name="smobile" required="">
                                        </div>
										
										
	
	<div class="form-group col-12">
										<h5 class="h5_set"><i class="fa fa-signal"></i> Onesignal Information</h5>
										</div>
										<div class="form-group col-6">
                                            <label><span class="text-danger">*</span> User App Onesignal App Id</label>
                                            <input type="text" class="form-control " placeholder="Enter User App Onesignal App Id"  value="<?php echo $data['one_key'];?>" name="one_key" required="">
                                        </div>
										
										<div class="form-group col-6">
                                            <label><span class="text-danger">*</span> User  App Onesignal Rest Api Key</label>
                                            <input type="text" class="form-control " placeholder="Enter User Boy App Onesignal Rest Api Key"  value="<?php echo $data['one_hash'];?>" name="one_hash" required="">
                                        </div>
	
										<div class="form-group col-6">
                                            <label><span class="text-danger">*</span> Delivery Boy App Onesignal App Id</label>
                                            <input type="text" class="form-control " placeholder="Enter Delivery Boy App Onesignal App Id"  value="<?php echo $data['d_key'];?>" name="d_key" required="">
                                        </div>
										
										<div class="form-group col-6">
                                            <label><span class="text-danger">*</span> Delivery Boy App Onesignal Rest Api Key</label>
                                            <input type="text" class="form-control " placeholder="Enter Delivery Boy App Onesignal Rest Api Key"  value="<?php echo $data['d_hash'];?>" name="d_hash" required="">
                                        </div>
										
										
										
										<div class="form-group col-12">
										<h5 class="h5_set"><i class="fa fa-user-plus" aria-hidden="true"></i> Refer And Earn Information</h5>
										</div>
										
										<div class="form-group col-6">
                                            <label><span class="text-danger">*</span> Sign Up Credit</label>
                                            <input type="text" class="form-control numberonly" placeholder="Enter Sign Up Credit"  value="<?php echo $data['scredit'];?>" name="scredit" required="">
                                        </div>
										
										<div class="form-group col-6">
                                            <label><span class="text-danger">*</span> Refer Credit</label>
                                            <input type="text" class="form-control numberonly" placeholder="Enter Refer Credit"  value="<?php echo $data['rcredit'];?>" name="rcredit" required="">
                                        </div>
										
									<div class="form-group mb-3 col-4">
                                            <label><span class="text-danger">*</span> Sms Type</label>
                                           <select class="form-control" name="sms_type">
										   <option value="">select sms type</option>
										   <option value="Msg91" <?php if($set['sms_type'] == 'Msg91'){echo 'selected';}?>>Msg91</option>
										   <option value="Twilio" <?php if($set['sms_type'] == 'Twilio'){echo 'selected';}?>>Twilio</option>
										  
										   </select>
                                        </div>
										
										<div class="form-group mb-3 col-12">
										<h5 class="h5_set"><i class="fas fa-sms"></i> Msg91 Sms Configurations</h5>
										</div>
	                                    
										<div class="form-group mb-3 col-6">
                                            <label><span class="text-danger">*</span>Msg91 Auth Key</label>
                                            <input type="text" class="form-control " placeholder="Msg91 Auth Key"  value="<?php echo $set['auth_key'];?>" name="auth_key" required="">
                                        </div>
										
										<div class="form-group mb-3 col-6">
                                            <label><span class="text-danger">*</span> Msg91 Otp Template Id</label>
                                            <input type="text" class="form-control " placeholder="Msg91 Otp Template Id"  value="<?php echo $set['otp_id'];?>" name="otp_id" required="">
                                        </div>
										
										
										<div class="form-group mb-3 col-12">
										<h5 class="h5_set"><i class="fas fa-sms"></i> Twilio Sms Configurations </h5>
										</div>
										
										<div class="form-group mb-3 col-4">
                                            <label><span class="text-danger">*</span>Twilio Account SID</label>
                                            <input type="text" class="form-control " placeholder="Twilio Account SID"  value="<?php echo $set['acc_id'];?>" name="acc_id" required="">
                                        </div>
										
										<div class="form-group mb-3 col-4">
                                            <label><span class="text-danger">*</span> Twilio Auth Token</label>
                                            <input type="text" class="form-control " placeholder="Twilio Auth Token"  value="<?php echo $set['auth_token'];?>" name="auth_token" required="">
                                        </div>
										
										<div class="form-group mb-3 col-4">
                                            <label><span class="text-danger">*</span> Twilio Phone Number</label>
                                            <input type="text" class="form-control " placeholder="Twilio Phone Number"  value="<?php echo $set['twilio_number'];?>" name="twilio_number" required="">
                                        </div>
										
										
										<div class="form-group mb-3 col-12">
										<h5 class="h5_set"><i class="fa fa-phone"></i> Otp Configurations</h5>
										</div>
										
										<div class="form-group mb-3 col-4">
                                            <label><span class="text-danger">*</span> Otp Auth In Sign up ? </label>
                                            <select class="form-control" name="otp_auth">
										   <option value="">Select Option</option>
										   <option value="Yes" <?php if($set['otp_auth'] == 'Yes'){echo 'selected';}?>>Yes</option>
										   <option value="No" <?php if($set['otp_auth'] == 'No'){echo 'selected';}?>>No</option>
										   
										   </select>
                                        </div>
										
										<div class="col-12">
                                                <button type="submit" name="edit_setting" class="btn btn-primary mb-2">Edit Setting</button>
                                            </div>
											</div>
                                    </form>
				
										</div>
										</div>
										</div>
										</div>
                        <!-- end row -->
                    </div>
                    <!-- container-fluid -->
                </div>
                <!-- End Page-content -->

                <!-- Transaction Modal -->
              
                
               
            </div>
            <!-- end main content-->

        </div>
        
        

       <?php include 'include/lundryfoot.php';?>
	   
	   <?php 
		if(isset($_POST['edit_setting']))
		{
			$webname = mysqli_real_escape_string($lundry,$_POST['webname']);
			$timezone = $_POST['timezone'];
			$currency = $_POST['currency'];
			$smobile = $_POST['smobile'];
			$semail = $_POST['semail'];
			$gkey = $_POST['gkey'];
			$vehiid = $_POST['vehiid'];
			$couvid = $_POST['couvid'];
			$mobile = $_POST['mobile'];
			$kglimit = $_POST['kglimit'];
			$kgprice = $_POST['kgprice'];
			$pdboy = $_POST['pdboy'];
			$one_key = $_POST['one_key'];
			$sms_type = $_POST['sms_type'];
			$auth_key = $_POST['auth_key'];
			$otp_id = $_POST['otp_id'];
			$acc_id = $_POST['acc_id'];
			$auth_token = $_POST['auth_token'];
			$twilio_number = $_POST['twilio_number'];
			$otp_auth = $_POST['otp_auth'];
			$one_hash = $_POST['one_hash'];
			
			
			
			$d_key = $_POST['d_key'];
			$d_hash = $_POST['d_hash'];
			$scredit = $_POST['scredit'];
			$rcredit =$_POST['rcredit'];
			
			
			
			$rid = 1;
			$target_dir = "images/website/";
			$temp = explode(".", $_FILES["weblogo"]["name"]);
$newfilename = round(microtime(true)) . '.' . end($temp);
$target_file = $target_dir . basename($newfilename);


			
			if($_FILES["weblogo"]["name"] != '')
	{
		
		move_uploaded_file($_FILES["weblogo"]["tmp_name"], $target_file);
		$table="tbl_setting";
  $field = array('smobile'=>$smobile,'semail'=>$semail,'kgprice'=>$kgprice,'kglimit'=>$kglimit,'couvid'=>$couvid,'vehiid'=>$vehiid,'gkey'=>$gkey,'timezone'=>$timezone,'weblogo'=>$target_file,'webname'=>$webname,'currency'=>$currency,'pdboy'=>$pdboy,'one_key'=>$one_key,'one_hash'=>$one_hash,'d_key'=>$d_key,'d_hash'=>$d_hash,'scredit'=>$scredit,'rcredit'=>$rcredit,
					'otp_auth'=>$otp_auth,
					'twilio_number'=>$twilio_number,
					'auth_token'=>$auth_token,
					'acc_id'=>$acc_id,
					'otp_id'=>$otp_id,
					'auth_key'=>$auth_key,
					'sms_type'=>$sms_type);
  $where = "where id=".$rid."";
$h = new Laundrore();
	  $check = $h->lundryupdateData($field,$table,$where);
	  
if($check == 1)
{
?>
<script>
 iziToast.success({
    title: 'Setting Section!!',
    message: 'Setting Update Successfully!!',
    position: 'topRight'
  });
				 setTimeout(function(){ 
	 window.location.href="setting.php"},3000);
  
  </script>
  
<?php 
}

	}
else 
{
	$table="tbl_setting";
  $field = array('smobile'=>$smobile,'semail'=>$semail,'kgprice'=>$kgprice,'kglimit'=>$kglimit,'couvid'=>$couvid,'vehiid'=>$vehiid,'gkey'=>$gkey,'timezone'=>$timezone,'webname'=>$webname,'currency'=>$currency,'pdboy'=>$pdboy,'one_key'=>$one_key,'one_hash'=>$one_hash,'d_key'=>$d_key,'d_hash'=>$d_hash,'scredit'=>$scredit,'rcredit'=>$rcredit,
					'otp_auth'=>$otp_auth,
					'twilio_number'=>$twilio_number,
					'auth_token'=>$auth_token,
					'acc_id'=>$acc_id,
					'otp_id'=>$otp_id,
					'auth_key'=>$auth_key,
					'sms_type'=>$sms_type);
  $where = "where id=".$rid."";
$h = new Laundrore();
	  $check = $h->lundryupdateData($field,$table,$where);
	  
if($check == 1)
{
?>
<script>
 iziToast.success({
    title: 'Setting Section!!',
    message: 'Setting Update Successfully!!',
    position: 'topRight'
  });
				 setTimeout(function(){ 
	 window.location.href="setting.php"},3000);
  
  </script>
  
<?php 
}

}	
		}
		?>
    </body>



</html>