<?php
require dirname( dirname(__FILE__) ).'/include/lanconfig.php';
?>
